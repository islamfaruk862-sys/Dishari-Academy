# Dishari Academy — Realistic School Website + Management Dashboard

This package contains a polished, mobile-responsive public school website and a demo management dashboard using the supplied Dishari Academy logo and photographs.

## Public website
Open `index.html` after extracting the ZIP.

## Admin dashboard
Open `admin.html`.
Demo login:
- Email: admin@dishariacademy.local
- Password: admin123

## Included modules
- Home / About / Academics
- Admission information
- Notice board
- Photo gallery using supplied photos
- Contact and Google Maps link
- Student management
- Teacher/staff management
- Attendance
- Fees & accounts
- Exams & results
- Admission applications
- Notice management
- Gallery
- School settings

## Important
The management dashboard in this free version is a front-end demo. Records are saved only in the current browser using localStorage. For a real school with multiple admins/teachers and shared data, connect a backend/database such as Supabase or PHP + MySQL and add secure authentication.

## Free deployment
### Netlify
1. Extract this ZIP.
2. Open Netlify and choose Add new project / Deploy manually.
3. Upload the extracted project folder (or drag the folder contents into the deploy area, depending on the current Netlify UI).
4. Netlify gives you a free `*.netlify.app` address.

### GitHub Pages
1. Create a GitHub repository.
2. Upload all extracted files and the `assets` folder.
3. In repository Settings → Pages, select Deploy from branch → main → root.
4. Save and wait for the Pages URL.

## Google Search
After the site is live, add the live site to Google Search Console and submit `sitemap.xml`. Replace the canonical URL in `index.html` with your real domain before requesting indexing.
